<?php
use \Core\App;
require "../core/App.php";

$app = new App();