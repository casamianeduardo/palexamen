<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Usuario</title>
</head>
<body>
    <h1>Detalle de usuario</h1>
    <ul>
        <li>Usuario número: <?= $user[0] ?></li>
        <li>Nombre: <?= $user[1] ?></li>
    </ul>
</body>
</html>