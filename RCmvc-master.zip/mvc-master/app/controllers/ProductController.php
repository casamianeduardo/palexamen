<?php
namespace App\Controllers;

class ProductController  
{
    public function __construct()
    {
        echo "en ProductController<br>";
    }
    public function index()
    {
        echo "En método index<br>";
    }
}
