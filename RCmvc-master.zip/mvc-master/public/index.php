<?php
#Fichero `mvc/public/index.php`
// echo 'Contenido en public<br>';
require "../start.php";