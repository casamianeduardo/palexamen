<?php
#fichrero config/db.php
namespace Config;
//en db pone unas constantes que se refieren a la base de datos
const DSN = 'mysql:dbname=mvc;host=db';
const USER = 'root';
const PASSWORD = 'password';

//podriamos poner otra base de datos del trabajo, supongo