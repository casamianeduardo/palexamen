<!doctype html>
<html lang="en">
  <!-- este es para relativas efectivamente, el otro para absolutas -->
<?php require __DIR__ . "/head.php" ?>

  <body>
    <?php require __DIR__ . "/header.php" ?>
   

    <!-- Begin page content -->
    <main role="main" class="container">
      <h1 class="mt-5">KESMO DEEW</h1>
      <p class="lead">sdafafasfasfasfasfswalalalalalala<code>padding-top: 60px;</code> on the <code>body &gt; .container</code>.</p>
      <p>Back to <a href="../sticky-footer/">the default sticky footer</a> minus the navbar.</p>
    </main>
    <!--  -->
    <?php require __DIR__ . "/footer.php" ?>

    
