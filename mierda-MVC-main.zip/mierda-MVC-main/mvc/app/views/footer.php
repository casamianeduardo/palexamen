<footer class="footer">
      <div class="container">
        <span class="text-muted">Este es un footer de los cohones.</span>
      </div>
    </footer>

    
  </body>
</html>