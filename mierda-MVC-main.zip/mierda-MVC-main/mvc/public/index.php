<?php
    //cuidado con los echos donde no tienen que estar
    //que nos saldra lo de headers already been sent
    //buscar echos var_dumps y prints cuando pase eso

    
    //asi conecto la parte publica con la parte privada
    //start php no esta en public
    require "../start.php";

    // //esto es para probar
    // require "../Controller.php";
    // $controller = new Controller();
    
    // //esto es para porbarlo, llamada a cada metodo
    // //$controller->show();
    // $controller->home();
    