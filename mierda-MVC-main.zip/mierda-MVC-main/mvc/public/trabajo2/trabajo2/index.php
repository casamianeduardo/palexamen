<?php

require_once "App.php";
$app = new App;
$app->run();