


<h1>Detalle de la  Persona <?php echo $empresa->nombre ?></h1>

<ul>
    
    <li><strong>Nombre: </strong><?php echo $empresa->nombre ?></li>
    <li><strong>Direccion: </strong><?php echo $empresa->direccion ?></li>
    <li><strong>Telefono: </strong><?php echo $empresa->telefono ?></li>
    <li><strong>Email: </strong><?php echo $empresa->email ?></li>
</ul>