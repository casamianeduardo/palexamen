


<h1>Detalle de la  Persona <?php echo $persona->nombre ?></h1>

<ul>
    
    <li><strong>Nombre: </strong><?php echo $persona->nombre ?></li>
    <li><strong>Apellidos: </strong><?php echo $persona->appelidos ?></li>
    <li><strong>Direccion: </strong><?php echo $persona->direccion ?></li>
    <li><strong>Telefono: </strong><?php echo $persona->telefono ?></li>
</ul>